
	var isIE6 = false;
    document.write("<!--[if lte IE 6]><script>isIE6=true;</scr" + "ipt><![endif]-->");
    if (isIE6) {
        document.getElementById("focus_au_21360").style.filter = "";
    }

    var n_21360 = 0;
    function Mea_21360(value) {
        n_21360 = value;
        setBg_21360(value);
        plays_21360(value);
        conaus_21360(n_21360);
    }
    function setBg_21360(value) {
        for (var i = 0; i < 6; i++)
            document.getElementById("focus_t_21360_" + i + "").className = "focus_bg_21360";
        document.getElementById("focus_t_21360_" + value + "").className = "focus_active_21360";
    }
    function plays_21360(value) {
        if (isIE6) {
            var d = document.getElementById("focus_au_21360").getElementsByTagName("div");
            for (i = 0; i < 6; i++)i == value ? d[i].style.display = "block" : d[i].style.display = "none";
        }
        else {
            try {
                with (focus_au_21360) {
                    filters[0].Apply();
                    for (i = 0; i < 6; i++)i == value ? children[i].style.display = "block" : children[i].style.display = "none";
                    filters[0].play();
                }
            }
            catch (e) {
                var d = document.getElementById("focus_au_21360").getElementsByTagName("div");
                for (i = 0; i < 6; i++)i == value ? d[i].style.display = "block" : d[i].style.display = "none";
            }
        }
    }
    function conaus_21360(value) {
        try {
            with (focus_conau_21360) {

                for (i = 0; i < 6; i++)i == value ? children[i].style.display = "block" : children[i].style.display = "none";

            }
        }
        catch (e) {
            var d = document.getElementById("focus_conau_21360").getElementsByTagName("div");
            for (i = 0; i < 6; i++)i == value ? d[i].style.display = "block" : d[i].style.display = "none";
        }

    }
    function clearAuto_21360() { clearInterval(autoStart_21360) }
    function setAuto_21360() { autoStart_21360 = setInterval("auto_21360(n_21360)", 4000) }
    function auto_21360() {
        n_21360++;
        if (n_21360 > 5) n_21360 = 0;
        Mea_21360(n_21360);
        conaus_21360(n_21360);
    }
    setAuto_21360();